<?php
include '../connection.php';
unset($_SESSION['employee']);
echo "<script>location='./login.php'</script>";
